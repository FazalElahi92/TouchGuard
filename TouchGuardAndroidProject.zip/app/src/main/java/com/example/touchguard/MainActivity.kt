package com.example.touchguard

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val requestOverlay = 2104

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showScreen()
    }

    override fun onResume() {
        super.onResume()
        // Refresh instructions after returning from Android's overlay permission screen.
        if (Settings.canDrawOverlays(this)) showScreen()
    }

    private fun showScreen() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
        }
        val title = TextView(this).apply {
            text = "Touch Guard"
            textSize = 28f
        }
        val info = TextView(this).apply {
            text = "A movable floating toggle keeps the screen awake and blocks accidental touches while Lock is ON. The floating toggle remains usable to unlock."
            textSize = 16f
            setPadding(0, 20, 0, 24)
        }
        val action = Button(this).apply {
            text = if (Settings.canDrawOverlays(this@MainActivity)) "Start floating toggle" else "Grant overlay permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivityForResult(intent, requestOverlay)
                } else {
                    val service = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
                    else startService(service)
                    finish()
                }
            }
        }
        val note = TextView(this).apply {
            text = "Note: Android may still allow system UI such as the status bar, navigation controls, emergency screens, or permission dialogs. If the service is stopped, touch blocking ends."
            textSize = 13f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(title)
        layout.addView(info)
        layout.addView(action, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        layout.addView(note)
        setContentView(layout)
    }

    @Deprecated("Deprecated by Android; retained for compatibility with the overlay settings flow")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        showScreen()
    }
}
