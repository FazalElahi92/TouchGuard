package com.example.touchguard

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var blocker: FrameLayout? = null
    private var bubble: TextView? = null
    private var locked = false
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var blockerParams: WindowManager.LayoutParams? = null
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForeground(42, makeNotification())
        showBubble()
        setLocked(false)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun makeNotification(): Notification {
        val channelId = "touch_guard_running"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Touch Guard", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, channelId) else Notification.Builder(this)
        return builder.setContentTitle("Touch Guard is running")
            .setContentText("Use the floating toggle to lock or unlock touch input.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setOngoing(true)
            .build()
    }

    @Suppress("DEPRECATION")
    private fun overlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun showBubble() {
        if (bubble != null) return
        val b = TextView(this).apply {
            text = "●"
            textSize = 24f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xCC263238.toInt())
                setStroke(dp(1), 0x99FFFFFF.toInt())
            }
            contentDescription = "Touch Guard toggle; drag the small handle to move"
            elevation = dp(12).toFloat()
        }
        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            val handle = View(this@OverlayService).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dp(4).toFloat()
                    setColor(0xCCB0BEC5.toInt())
                }
            }
            addView(handle, FrameLayout.LayoutParams(dp(8), dp(22), Gravity.CENTER_VERTICAL or Gravity.LEFT))
            addView(b, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
        }
        // The bubble's whole area is draggable; a short drag moves it, a tap toggles lock.
        container.setOnTouchListener { _, event ->
            val p = bubbleParams ?: return@setOnTouchListener true
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = p.x; startY = p.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - downX).toInt()
                    val dy = (event.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(5) || kotlin.math.abs(dy) > dp(5)) moved = true
                    if (moved) {
                        p.x = startX + dx
                        p.y = startY + dy
                        try { wm.updateViewLayout(container, p) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) setLocked(!locked)
                    true
                }
                else -> true
            }
        }
        val params = WindowManager.LayoutParams(
            dp(62), dp(62), overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.LEFT
            x = dp(12); y = dp(180)
        }
        bubble = null // rootBubble holds the floating container view
        rootBubble = container
        bubbleParams = params
        wm.addView(container, params)
        updateBubbleAppearance()
    }

    private var rootBubble: View? = null

    private fun setLocked(value: Boolean) {
        locked = value
        if (value) {
            if (blocker == null) {
                val layer = FrameLayout(this).apply {
                    // A fully transparent view still receives touches across its rectangular bounds.
                    setBackgroundColor(Color.TRANSPARENT)
                    isClickable = true
                    isFocusable = false
                    setOnTouchListener { _, _ -> true }
                }
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    overlayType(),
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT
                ).apply {
                    gravity = Gravity.TOP or Gravity.LEFT
                }
                blocker = layer
                blockerParams = params
                try { wm.addView(layer, params) } catch (_: Exception) { blocker = null }
            }
        } else {
            blocker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
            blocker = null
            blockerParams = null
        }
        // Re-add bubble after blocker so it stays above the touch-blocking layer.
        val root = rootBubble
        val bp = bubbleParams
        if (root != null && bp != null) {
            try { wm.removeView(root) } catch (_: Exception) {}
            try { wm.addView(root, bp) } catch (_: Exception) {}
        }
        updateBubbleAppearance()
    }

    private fun updateBubbleAppearance() {
        val root = rootBubble ?: return
        val b = root.findViewWithTag<TextView>("toggle_label")
        // Main bubble is the centered TextView child.
        val label = findTextChild(root)
        label?.text = if (locked) "Ⅱ" else "●"
        label?.setTextColor(if (locked) 0xFFFFD180.toInt() else Color.WHITE)
    }

    private fun findTextChild(v: View): TextView? {
        if (v is TextView) return v
        if (v is FrameLayout) {
            for (i in 0 until v.childCount) {
                val found = findTextChild(v.getChildAt(i))
                if (found != null) return found
            }
        }
        return null
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        blocker?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        rootBubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        blocker = null; rootBubble = null; bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
