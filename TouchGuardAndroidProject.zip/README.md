# Touch Guard (Android Studio project)

A minimal Kotlin Android app project for a movable overlay toggle.

## Build and install
1. Install Android Studio on a computer.
2. Open this `TouchGuard` folder as a project.
3. Let Gradle sync. Install an Android SDK platform for API 35 if Android Studio asks.
4. Connect your phone with USB debugging enabled, or build an APK via **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Install the APK on the Tecno phone.
6. Open Touch Guard and grant **Display over other apps** permission.
7. Tap **Start floating toggle**. Tap the floating dot to turn touch blocking on/off. Drag the floating control to reposition it.

## Behavior and limitations
- When ON, the service adds a transparent, full-window overlay that consumes touch events and requests `FLAG_KEEP_SCREEN_ON`.
- The floating toggle is re-added above the blocker so it remains tappable.
- When OFF, the blocker is removed while the floating toggle remains.
- Android restricts overlays around some system UI. This cannot promise to block the notification shade, navigation gestures, power menu, emergency UI, or every OEM system surface.
- If Android force-stops/kills the service, the overlay disappears. Use the persistent notification to identify that the service is running.
- The overlay permission is sensitive because overlays can obscure other apps. This project does not access the internet or collect data.

## Notes
This is source code, not a precompiled APK. It is an initial project and should be tested on the actual device. The target SDK is set to 28 to avoid requiring newer foreground-service type declarations; Android may still show compatibility warnings.
